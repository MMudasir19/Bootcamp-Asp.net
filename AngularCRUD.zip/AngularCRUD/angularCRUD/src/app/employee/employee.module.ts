import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MainComponent } from './main/main.component';
import { ShowComponent } from './show/show.component';
import { AddUpdateComponent } from './add-update/add-update.component';




@NgModule({
  declarations: [
    MainComponent,
    ShowComponent,
    AddUpdateComponent
  ],
  imports: [
    CommonModule,
    FormsModule
  ],
  exports:[
    MainComponent,
    ShowComponent,
    AddUpdateComponent
  ]
})
export class EmployeeModule { }
