import { Component, Input, OnInit, } from '@angular/core';
import { SharedService } from 'src/app/service/shared.service';
import { Employee } from 'src/Models/Employee';

@Component({
  selector: 'app-add-update',
  templateUrl: './add-update.component.html',
  styleUrls: ['./add-update.component.css']
}) 
export class AddUpdateComponent implements OnInit {

  constructor(private service:SharedService) { }

  @Input() emp:Employee = {} as Employee;
  //@Input() emp:any;
  employeeName:string="";
  employeeCity:string="";
  employeeGender:string="";
  employeeID:number=0;

  ngOnInit(): void {
    this.employeeName=this.emp.EmpName;
    this.employeeCity=this.emp.City;
    this.employeeGender=this.emp.Gender;
    this.employeeID=this.emp.EmployeeID;
  }

  addEmployee(){
    var newEmployee = {
      EmpName:this.employeeName,
      City:this.employeeCity,
      Gender:this.employeeGender,
    }
    this.service.addEmployee(newEmployee).subscribe(res =>{
      alert(res.toString());
    });
  }

  // Update Employee Function
  updateEmployee(){
    var newEmplyee = {
      EmployeeID:this.employeeID,
      EmpName:this.employeeName,
      City:this.employeeCity,
      Gender:this.employeeGender,
    }
    this.service.updateEmployee(newEmplyee).subscribe(res =>{
      alert(res.toString());
    });
  }

}
