import { Component, OnInit } from '@angular/core';
import { SharedService } from 'src/app/service/shared.service';
import { Employee } from 'src/Models/Employee';

@Component({
  selector: 'app-show',
  templateUrl: './show.component.html',
  styleUrls: ['./show.component.css']
})
export class ShowComponent implements OnInit {

  constructor(private service:SharedService) { }

  //Declaration of variables to be used by component
  employeeList:any=[];
  modalTitle:string="";
  ActivateAddEditEmployee:boolean=false;
  tempEmp:any;

  ngOnInit(): void {
    this.refreshEmployeeList();
  }

  refreshEmployeeList(){
    this.service.getEmpList().subscribe(data =>{
      this.employeeList=data;
    });
  }

  addEmployee(){
    this.tempEmp={
      EmpName:"",
      City:"",
      Gender:""
    }
    this.modalTitle="Add Employee";
    this.ActivateAddEditEmployee=true;
  }

  closeClick(){
    this.ActivateAddEditEmployee=false;
    this.refreshEmployeeList();
  }

  editEmployee(emp:Employee){
    this.tempEmp=emp;
    this.modalTitle="Edit Employee";
    this.ActivateAddEditEmployee=true;
  }

  deleteEmployee(emp:Employee){
   if(confirm('Are you Sure?')){
    this.service.deleteEmployee(emp.EmployeeID).subscribe(data =>{
      alert(data.toString());
      this.refreshEmployeeList();
    });
   } 
  }
}
