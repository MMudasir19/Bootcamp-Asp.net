export class Employee{
    EmployeeID!:number;
    EmpName!:string;
    City!:String;
    Gender!:string;
}