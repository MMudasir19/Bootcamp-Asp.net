export class Employee{
    EmployeeID!:number;
    EmpName!:string;
    City!:string;
    Gender!:string;
}