﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace projectPointOfSale
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Login_Click(object sender, EventArgs e)
        {
            if (dropdown.SelectedValue == "1")
            {
                if (name.Text == "Admin" && word.Text == "pass")
                {
                    Response.Redirect("admin.aspx");
                }
                else
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('UserId or Password is invalid')", true);
                }
            }
            else if (dropdown.SelectedValue == "2")
            {
                if (name.Text == "Accountant" && word.Text == "pass")
                {
                    Response.Redirect("accountant.aspx");
                }
                else
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('UserId or Password is invalid')", true);
                }
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('select any option')", true);
            }
        }
    }
}