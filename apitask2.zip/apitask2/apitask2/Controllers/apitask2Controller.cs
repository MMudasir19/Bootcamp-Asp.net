﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Data;
using Newtonsoft.Json;
using System.Runtime.Caching;
using System.Web.Configuration;

namespace apitask2.Controllers
{
    public class info
    {
        public int id { get; set; }
        public string name { get; set; }
    }
    public class SQLDataHelper
    {
        string cs = "";
        public SQLDataHelper()
        {
            cs = WebConfigurationManager.ConnectionStrings["mudasir4135"].ConnectionString;
        }

        public List<info> Getvalues()
        {
            List<info> lstStudent = new List<info>();

            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();
                string qeury = "select * From Names";

                SqlCommand cmd = new SqlCommand(qeury, con);


                SqlDataReader rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    info std = new info();

                    std.id = Convert.ToInt32(rdr["id"].ToString());
                    std.name = (rdr["name"].ToString());


                    lstStudent.Add(std);
                }
                con.Close();
            }
            return lstStudent;
        }
    }
       

        public class apitask2Controller : ApiController
    {
        // GET api/apitask2
        public List<info> Get()
        {
            ObjectCache cache = MemoryCache.Default;
            if (cache["info"] == null)
            {
                var cacheItemPolicy = new CacheItemPolicy
                {
                    AbsoluteExpiration = DateTimeOffset.Now.AddHours(1)
                };
                SQLDataHelper sqlData = new SQLDataHelper();
                var cacheItem = new CacheItem("info", sqlData.Getvalues());
                cache.Add(cacheItem, cacheItemPolicy);
            }
            return (List<info>)cache.Get("info");
        }

    }
}
