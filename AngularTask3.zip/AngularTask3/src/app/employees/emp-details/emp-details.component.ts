import { Component, Input, OnInit } from '@angular/core';
import { MasterService } from 'src/app/master.service';
import { Employee } from '../employees.module';


@Component({
  selector: 'app-emp-details',
  templateUrl: './emp-details.component.html',
  styleUrls: ['./emp-details.component.css']
})
export class EmpDetailsComponent implements OnInit {
  emp:Employee[]=[];
  constructor(private employeeService:MasterService) { }

  ngOnInit(): void { this.emp =this.employeeService.GetEmployee();
  }
  @Input() tempEmployee!:Employee;
  PreviousEmployee(employee:Employee){
    let index = this.emp.indexOf(employee);
    if(index !== 0)
    {
      this.tempEmployee = this.emp[this.emp.indexOf(this.tempEmployee) - 1]    
    }
    else{
      alert("There is no previous element to the current one");
    }
  } NextEmployee(employee:Employee){
    let index = this.emp.indexOf(employee);
    if(index !== this.emp.length - 1)
    {
      this.tempEmployee = this.emp[this.emp.indexOf(this.tempEmployee) + 1]    
    }
    else{
      alert("There is no next element to the present one");
    }
  }

}
