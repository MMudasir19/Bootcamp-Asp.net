import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { MasterService } from 'src/app/master.service';
import { Employee } from '../employees.module';

@Component({
  selector: 'app-emp-list',
  templateUrl: './emp-list.component.html',
  styleUrls: ['./emp-list.component.css']
})
export class EmpListComponent implements OnInit {
  employee : Employee[]=[];
  @Output() ShowEmployee:EventEmitter<Employee>=new EventEmitter();
  constructor(private employeeService:MasterService ) { }

  ngOnInit(): void { this.employee=this.employeeService.GetEmployee();
  }
  onSelect(emp:Employee){
    this.ShowEmployee.emit(emp);
  }
}
