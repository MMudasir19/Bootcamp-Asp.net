﻿namespace Intelisencarlist
{
    public class string_carName
    {
    }
}