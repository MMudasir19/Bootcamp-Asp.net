﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Intelisencarlist
{
  
    public partial class Intellisensecarlist : Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
          

        }
        [WebMethod]
        public static List<string> Getcar(string _carName)
        {

            List<string> dat = new List<string>();
            dat.Add("audi");
            dat.Add("corolla");
            dat.Add("A3");
            dat.Add("suzuki");
            dat.Add("alto");
            dat.Add("mercedes");
            dat.Add("bmw");
            dat.Add("nissan");
            dat.Add("gtr");
            dat.Add("corolla gli");
            dat.Add("A4");
            dat.Add("mehran");
            dat.Add("charade");
            dat.Add("fiat");
            dat.Add("passo");
            dat.Add("wagon R");
            dat.Add("corolla G");
            dat.Add("A5");
            dat.Add("lexus");
            dat.Add("revo");
            
        
         
            List<string> car = new List<string>();
            for (int x=0; x< dat.Count; x++)
            {
                if (dat[x].Contains(_carName))
                {
                    car.Add(dat[x]);
                }
            }
            return car;

            }
            
        }
    }
