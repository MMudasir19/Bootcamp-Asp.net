﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Http;
using System.Web.Routing;

namespace AngularApi1.Controllers
{
    public class AngularApi1Controller : ApiController
    {
        public class info
        {
            public int ID { get; set; }
            public string Name { get; set; }
            public string Role { get; set; }
            public int Age { get; set; }
        }
        [Route("students")]
        public List<info> get()
        {
            List<info> Students = new List<info>();
            string CS = ConfigurationManager.ConnectionStrings["mudasir4135"].ConnectionString;
            using (SqlConnection con = new SqlConnection(CS))
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM info", con);
                //cmd.CommandType = CommandType.Text;
                con.Open();

                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    var information = new info();

                    information.ID = Convert.ToInt32(rdr["ID"]);
                    information.Name = rdr["Name"].ToString();
                   

                    Students.Add(information);
                }
                con.Close();
            }
            return Students;
        }
        [Route("studentDetail")]
        public info Get(int ID)
        {
            info StdDetails = new info();
            string CS = ConfigurationManager.ConnectionStrings["mudasir4135"].ConnectionString;
            using (SqlConnection con = new SqlConnection(CS))
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM info where ID= '"+ ID +"'", con);
                //cmd.CommandType = CommandType.Text;
                con.Open();

                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {


                    StdDetails.ID = Convert.ToInt32(rdr["ID"]);
                    StdDetails.Name = rdr["Name"].ToString();
                    StdDetails.Role = rdr["Role"].ToString();
                    StdDetails.Age = Convert.ToInt32(rdr["Age"]);

                    
                }
                con.Close();
            }
            return StdDetails;
        }

    }
}
