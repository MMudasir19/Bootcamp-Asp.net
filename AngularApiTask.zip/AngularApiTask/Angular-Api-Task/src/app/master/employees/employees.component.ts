import { Component, OnInit } from '@angular/core';
import { Info } from 'src/app/master';

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css']
})
export class EmployeesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  personDetails!:Info;
  selectedperson(info:Info){
    this.personDetails=info;
  }
}
