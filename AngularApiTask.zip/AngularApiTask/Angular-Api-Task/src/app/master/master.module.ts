import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmpListComponent } from './emp-list/emp-list.component';
import { EmpDetailsComponent } from './emp-details/emp-details.component';
import { EmployeesComponent } from './employees/employees.component';



@NgModule({
  declarations: [

    EmpListComponent,
    EmpDetailsComponent,
    EmployeesComponent
  ],
  imports: [
    CommonModule
  ],
  exports:[
    EmpListComponent,
    EmpDetailsComponent,
    EmployeesComponent
  ]
})
export class MasterModule { }
