import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { map } from 'rxjs';
import { Info } from 'src/app/master';
import { HeroService } from 'src/app/service/hero.service';

@Component({
  selector: 'app-emp-list',
  templateUrl: './emp-list.component.html',
  styleUrls: ['./emp-list.component.css']
})
export class EmpListComponent implements OnInit {

  info: Info[]=[];
  infoDetail !: Info;
  @Output() Showinfo:EventEmitter<Info>=new EventEmitter();
  

  constructor(private infoservice:HeroService) { }

  ngOnInit(): void {
  this.infoservice.getlist().pipe(
    map((data : Info[])=>{
      if(data !==null && data !==undefined)
      {
        this.info =data;
      }
      console.log(this.info);
    })
   ).subscribe();

  }
  onSelect(information : Info){
  this.infoservice.getlistDetail(information.ID).pipe(
    map((data : Info)=>{
      if(data !==null && data !==undefined)
      {
        this.infoDetail =data;
      }
      this.Showinfo.emit(this.infoDetail);
      console.log(this.infoDetail);
    })
   ).subscribe();
  }



  /*  
  Previous(info:Info){
         let index = this.info.indexOf(info);
         if(index !== 0)
         {
           this.tempinfo = this.info[this.info.indexOf(this.tempinfo) - 1]    
         }
         else{
           alert("There is no previous element to the current one");
         }
       }
        Next(info:Info){
         let index = this.info.indexOf(info);
         if(index !== this.info.length - 1)
         {
           this.tempinfo = this.info[this.info.indexOf(this.tempinfo) + 1]    
         }
         else{
           alert("There is no next element to the present one");
         }
       }   
*/  
}
