import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { map } from 'rxjs';
import { Info } from 'src/app/master';
import { HeroService } from 'src/app/service/hero.service';

@Component({
  selector: 'app-emp-details',
  templateUrl: './emp-details.component.html',
  styleUrls: ['./emp-details.component.css']
})
export class EmpDetailsComponent implements OnInit {
  @Input() info!:Info;

  
  constructor(private infoservice:HeroService) { }

  ngOnInit(): void {
    }

}
