import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Info } from '../master';

@Injectable({
  providedIn: 'root'
})
export class HeroService {

private _url: string = 'http://localhost/AngularApi/students';
  
constructor(private http:HttpClient) { }
  

getlist():Observable<Info[]>{
    return this.http.get<Info[]>(this._url); 
}
getlistDetail(id :number):Observable<Info>{
  return this.http.get<Info>('http://localhost/AngularApi/studentDetail?id='+id);
}
}
