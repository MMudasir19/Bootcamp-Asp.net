export interface Info{ 
    ID: number,
    Name: string,
    Role: string,
    Age: number
}