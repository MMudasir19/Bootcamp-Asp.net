//class for Holidays
export class Holidays
    {
        Id: number=0;
        CountryId: number=0;
        HolidayDate: Date; 
    }

