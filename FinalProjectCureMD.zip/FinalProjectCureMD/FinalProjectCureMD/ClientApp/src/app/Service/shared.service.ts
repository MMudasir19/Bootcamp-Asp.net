import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SharedService {
    //url for the API
    readonly Url = 'https://localhost:44326/';
    constructor(private http: HttpClient) { }
    
    //service function for getting countries list
    getCountries(): Observable<any[]> {
        return this.http.get<any>(this.Url + '/GetCountries');
    }

     //service function for getting panelty and Business Days
    Calculate(): Observable<any[]> {
        return this.http.get<any>(this.Url + '/Calculate');
    }
}
