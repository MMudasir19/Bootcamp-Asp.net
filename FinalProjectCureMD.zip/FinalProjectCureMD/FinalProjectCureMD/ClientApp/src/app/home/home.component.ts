import { Component, OnInit } from '@angular/core';
import { SharedService } from '../Service/shared.service';


@Component({
    selector: 'app-home',
    templateUrl: './home.component.html',
})
export class HomeComponent implements OnInit {

    constructor(private service: SharedService) { }
    //variable for using the service
    Countries: any = [];
    Calculate: any = [];

    ngOnInit(): void {
        //this use the service function getCountries to get countries names
        this.service.getCountries().subscribe(data => {
            this.Countries = data;
        });
        //this use the service function Calculate to get panelty value

        this.service.Calculate().subscribe(data => {
                this.Calculate = data;
            });
        }
    
}
