//class for Countries
export class Countries
    {
    CountryId: number=0;
    CountryName: string='';
    Currency: string='';
    CurrencyFormate: string='';
    phone_code: number=0;
    country_code: string=''; 
    currency_rate: number=0; 
    }

