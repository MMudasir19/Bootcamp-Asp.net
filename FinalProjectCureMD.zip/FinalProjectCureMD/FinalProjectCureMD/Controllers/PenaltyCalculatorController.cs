﻿using System;
using System.Collections.Generic;
using System.Linq;
using FinalProjectCureMD.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;

namespace FinalProjectCureMD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PenaltyCalculatorController : ControllerBase
    {
        private readonly panelty _dbContext;

        public PenaltyCalculatorController(panelty dbContext)
        {
            _dbContext = dbContext;
        }
        [HttpGet]
        [Route("Countries")]
        public List<Countries> GetCountries()
        {
            try
            {
                List<Countries> Students = new List<Countries>();
                string CS = dbContext.ConnectionStrings["mudasir4135"].ConnectionString;
                using (SqlConnection con = new SqlConnection(CS))
                {
                    SqlCommand cmd = new SqlCommand("SELECT * FROM info", con);
                    //cmd.CommandType = CommandType.Text;
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        var information = new Countries();

                        information.CountryId = Convert.ToInt32(rdr["CountryId"]);
                        information.CountryName = rdr["CountryName"].ToString();
                        information.Currency = rdr["Currency"].ToString();
                        information.CurrencyFormate = rdr["CurrencyFormate"].ToString();
                        information.country_code = rdr["country_code"].ToString();
                        information.phone_code = Convert.ToInt32(rdr["phone_code"]);


                        Students.Add(information);
                    }
                    con.Close();
                }
                return Students;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        [HttpGet]
        [Route("Calculatepanelty")]
        public string Calculate(int CountryId, DateTime startDate, DateTime endDate)
        {
            try
            {
                var country = _dbContext.Countries.Where(x => x.CountryId == CountryId).Select(x => new CountriesViewModel()
                {
                    CountryId = x.CountryId,
                    CountryName = x.CountryName,
                    Currency = x.Currency,
                    CurrencyFormate = x.Currency,
                    phone_code = x.phone_code,
                    country_code = x.country_code,
                    currency_rate = x.currency_rate

                }).FirstOrDefault();

                var panelty = _dbContext.Holidays.Where(o => o.CountryId == CountryId && startDate > o.HolidayDate && endDate <= o.HolidayDate).Select(o => new HolidaysViewModel()
                {
                    CountryId = o.CountryId,
                    HolidayDate = o.HolidayDate

                }).ToList();

                int allocatedDays = 10;
                double finePerDay = 50;
                finePerDay = finePerDay * country.currency_rate;

                int totalHolidays = panelty.Count();

                TimeSpan timeSpan = startDate - endDate;

                int totalDays = Convert.ToInt32(timeSpan.TotalDays);

                int workingDays = totalDays - totalHolidays;
                int usedDays = workingDays - allocatedDays;

                double totalAmount = 0;
                if (usedDays > allocatedDays)
                {
                    totalAmount = usedDays * finePerDay;
                }


                string fine = totalAmount + " " + country.CurrencyFormate;

                return fine;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}