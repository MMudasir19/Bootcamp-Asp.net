﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProjectCureMD.Models
{
    public class panelty : DbContext
    {
        public panelty(DbContextOptions<panelty>options):base(options) { }
        public DbSet<CountriesViewModel> Countries { get; set; }
        public DbSet<HolidaysViewModel> Holidays { get; set; }
    }
   
}
