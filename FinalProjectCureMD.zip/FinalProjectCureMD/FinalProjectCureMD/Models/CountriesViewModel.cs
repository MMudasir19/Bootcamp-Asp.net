﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProjectCureMD.Models
{
    public class CountriesViewModel
    {
        [Key]
        public int CountryId { get; set; }
        public string CountryName { get; set; }
        public string Currency { get; set; }
        public string CurrencyFormate { get; set; }
        public int phone_code { get; set; }
        public string country_code { get; set; }
        public double currency_rate { get; set; }
    }
}
