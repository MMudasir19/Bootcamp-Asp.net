﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProjectCureMD.Models
{
    public class HolidaysViewModel
    {
        [Key]
        public int Id { get; set; }
        public int CountryId { get; set; }
        public DateTime HolidayDate { get; set; }
    }
}
