import { Component, OnInit } from '@angular/core';
import { Employee } from '../task1.module';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  EmployeeDetials!:Employee;

  selectedEmployee(emp:Employee){
    this.EmployeeDetials=emp;
}
}
