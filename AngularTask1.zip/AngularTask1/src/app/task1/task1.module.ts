import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmployeeComponent } from './employee/employee.component';
import { EmployeelistComponent } from './employeelist/employeelist.component';
import { EmployeedetailsComponent } from './employeedetails/employeedetails.component';



@NgModule({
  declarations: [
    EmployeeComponent,
    EmployeelistComponent,
    EmployeedetailsComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    EmployeeComponent,
    EmployeelistComponent,
    EmployeedetailsComponent
  ]
})
export class Task1Module {
  selectedEmployee(emp:Employee){
    console.log(emp);
  } 
 }
 export class Employee{
  id!:number;
  name!:string;
  role!:string;
  gender!:string;
}
