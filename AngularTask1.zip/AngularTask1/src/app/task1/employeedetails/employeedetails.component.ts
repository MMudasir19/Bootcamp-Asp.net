import { Component, Input, OnInit, } from '@angular/core';
import { Employee } from '../task1.module';

@Component({
  selector: 'app-employeedetails',
  templateUrl: './employeedetails.component.html',
  styleUrls: ['./employeedetails.component.css']
})
export class EmployeedetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  @Input() tempEmployee!:Employee;
}
