﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace stateManagementTask3
{
    class User
    {
        public string UserName { get; set; }
        public string Password { get; set; }
        public User(string userName, string password)
        {
            UserName = userName;
            Password = password;
        }
    }
    public partial class stateManagementTask3 : System.Web.UI.Page
    {
        private readonly User user = new User("polar", "vezli");
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["userName"] != null && Session["userName"] != null)
                Response.Redirect("Greetings.aspx");
        }

        protected void LoginButton_Click(object sender, EventArgs e)
        {
            if (UserNameTextBox.Text == user.UserName && PasswordTextBox.Text == user.Password)
            {
                Session["userName"] = UserNameTextBox.Text;
                Session["password"] = PasswordTextBox.Text;
                Response.Redirect("Greetings.aspx");
            }
            else
                ErrLabel.Text = "Login credentials not found or do not match!";
        }
    }
}