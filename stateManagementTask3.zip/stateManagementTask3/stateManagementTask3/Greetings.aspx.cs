﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace stateManagementTask3
{
    public partial class Greetings : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["username"] == null && Session["username"] == null)
                Response.Redirect("stateManagementTask3.aspx");
            else
                GreetingHeader.InnerText = "Greetings " + Session["username"].ToString();
        }

        protected void LogoutButton_Click(object sender, EventArgs e)
        {
            Session.Clear();
            Response.Redirect("stateManagementTask3.aspx");
        }
    }
}