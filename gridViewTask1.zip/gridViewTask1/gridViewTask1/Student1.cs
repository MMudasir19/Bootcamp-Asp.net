﻿namespace gridViewTask1
{
    internal class Student
    {
        internal string Address;

        public Student()
        {
        }

        public string Name { get; set; }
        public int RollNum { get; set; }
        public string City { get; set; }
        public int Age { get; set; }
        public int RegistrationNumber { get; internal set; }
    }
}