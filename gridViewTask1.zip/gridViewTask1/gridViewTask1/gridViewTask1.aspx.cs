﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace gridViewTask1
{
    public partial class gridViewTask1 : System.Web.UI.Page
    {
        public class student
        {
           

            public student(string Name, int RollNum, string Address)
            {
                this.Name = Name;
                this.RollNum = RollNum;
                this.Address = Address;
            }

            public string Name { get; set; }
            public int RollNum { get; set; }
            public string Address { get; set; }
            
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            // List of Students for making a database
            List<student> dataBaseOfstudents = new List<student>();
            // dummy Students for populating Database
            student dummyStudent = new student("name", 1, "address");

            // Loop for populating list
            for (int i = 0; i < 10; i++)
            {
                dummyStudent = new student("name: " + i, 1 + i,("street No " + i + ", House No " + i + ", Area No " + i)); ;
                dataBaseOfstudents.Add(dummyStudent);
            }

            // binding of list
            if (!IsPostBack)
            {
                GridView1.DataSource = dataBaseOfstudents;
                GridView1.DataBind();
            }
        }
    }
}