﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Mvc;
using System.Data.SqlClient;
using System.Data;
using System.Web.Routing;

namespace APITask1.Controllers
{
    public class task1Controller : ApiController
    {
        public class info
        {
            public int ID { get; set; }
            public string Name { get; set; }
            public string Role { get; set; }
            public int Age { get; set; }
        }

       
        public List<info>  get()
        {
            List<info> Info = new List<info>();
            string CS = ConfigurationManager.ConnectionStrings["mudasir4135"].ConnectionString;
            using (SqlConnection con = new SqlConnection(CS))
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM info", con);
                //cmd.CommandType = CommandType.Text;
                con.Open();

                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    var information = new info();

                    information.ID = Convert.ToInt32(rdr["ID"]);
                    information.Name = rdr["Name"].ToString();
                    information.Role = rdr["Role"].ToString();
                    information.Age = Convert.ToInt32(rdr["Age"]);
                    
                    Info.Add(information);
                }
                con.Close();
            }
            return Info;
        }
    }

   
}
