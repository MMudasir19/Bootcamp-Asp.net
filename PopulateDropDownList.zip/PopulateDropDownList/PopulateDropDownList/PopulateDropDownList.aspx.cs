﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PopulateDropDownList
{
    public class Student
    {
        public string Name { get; set; }
        public int RollNum { get; set; }
        public string City { get; set; }
        public int Age { get; set; }
    }
    public partial class PopulateDropDownList : System.Web.UI.Page
    {
        List<Student> data = new List<Student>();
        protected void Page_Load(object sender, EventArgs e)
        {

            DataTable dt = new DataTable();

            var std1 = new Student()
            {
                Name = "Ali",
                RollNum = 1,
                City = "Lahore",
                Age = 10
            };
            var std2 = new Student()
            {
                Name = "Awais",
                RollNum = 2,
                City = "Lahore",
                Age = 11
            };
            var std3 = new Student()
            {
                Name = "Waqas",
                RollNum = 3,
                City = "Karachi",
                Age = 12
            };
            var std4 = new Student()
            {
                Name = "Asad",
                RollNum = 4,
                City = "Karachi",
                Age = 13
            };
            var std5 = new Student()
            {
                Name = "Ahmed",
                RollNum = 5,
                City = "Karachi",
                Age = 14
            };
            var std6 = new Student()
            {
                Name = "Ahmer",
                RollNum = 6,
                City = "Karachi",
                Age = 15
            };
            var std7 = new Student()
            {
                Name = "Saad",
                RollNum = 7,
                City = "Karachi",
                Age = 16
            };
            var std8 = new Student()
            {
                Name = "Saifullah",
                RollNum = 8,
                City = "Karachi",
                Age = 12
            };
            var std9 = new Student()
            {
                Name = "Farukh",
                RollNum = 9,
                City = "Karachi",
                Age = 14
            };
            var std10 = new Student()
            {
                Name = "Asim",
                RollNum = 10,
                City = "Karachi",
                Age = 16
            };
            var std11 = new Student()
            {
                Name = "Haris",
                RollNum = 11,
                City = "Karachi",
                Age = 19
            };
            var std12 = new Student()
            {
                Name = "Akbar",
                RollNum = 12,
                City = "Karachi",
                Age = 13
            };
            var std13 = new Student()
            {
                Name = "Aslam",
                RollNum = 13,
                City = "Karachi",
                Age = 23
            };
            var std14 = new Student()
            {
                Name = "Aswad",
                RollNum = 14,
                City = "Islamabad",
                Age = 15
            };
            var std15 = new Student()
            {
                Name = "Ahsan",
                RollNum = 15,
                City = "Islamabad",
                Age = 24
            };
            var std16 = new Student()
            {
                Name = "Abdullah",
                RollNum = 16,
                City = "Islamabad",
                Age = 17
            };
            var std17 = new Student()
            {
                Name = "Safiullah",
                RollNum = 17,
                City = "Faislabad",
                Age = 15
            };
            var std18 = new Student()
            {
                Name = "Saadullah",
                RollNum = 18,
                City = "Karachi",
                Age = 27
            };
            var std19 = new Student()
            {
                Name = "Faizan",
                RollNum = 19,
                City = "Quetta",
                Age = 17
            };
            var std20 = new Student()
            {
                Name = "Usama",
                RollNum = 20,
                City = "Karachi",
                Age = 22
            };
            data.Add(std1);
            data.Add(std2);
            data.Add(std3);
            data.Add(std4);
            data.Add(std5);
            data.Add(std6);
            data.Add(std7);
            data.Add(std8);
            data.Add(std9);
            data.Add(std10);
            data.Add(std11);
            data.Add(std12);
            data.Add(std13);
            data.Add(std14);
            data.Add(std15);
            data.Add(std16);
            data.Add(std17);
            data.Add(std18);
            data.Add(std19);
            data.Add(std20);

            DropDownList1.DataSource = data;
            DropDownList1.DataBind();
            DropDownList1.DataTextField = "Name";
            DropDownList1.DataValueField = "RollNum";
            DropDownList1.DataBind();
        }
        [WebMethod]
        public static Student GetStudent(int _rollNum)
        {
            var std1 = new Student()
            {
                Name = "Ali",
                RollNum = 1,
                City = "Lahore",
                Age = 10
            };
            var std2 = new Student()
            {
                Name = "Awais",
                RollNum = 2,
                City = "Lahore",
                Age = 11
            };
            var std3 = new Student()
            {
                Name = "Waqas",
                RollNum = 3,
                City = "Karachi",
                Age = 12
            };
            var std4 = new Student()
            {
                Name = "Asad",
                RollNum = 4,
                City = "Karachi",
                Age = 13
            };
            var std5 = new Student()
            {
                Name = "Ahmed",
                RollNum = 5,
                City = "Karachi",
                Age = 14
            };
            var std6 = new Student()
            {
                Name = "Ahmer",
                RollNum = 6,
                City = "Karachi",
                Age = 15
            };
            var std7 = new Student()
            {
                Name = "Saad",
                RollNum = 7,
                City = "Karachi",
                Age = 16
            };
            var std8 = new Student()
            {
                Name = "Saifullah",
                RollNum = 8,
                City = "Karachi",
                Age = 12
            };
            var std9 = new Student()
            {
                Name = "Farukh",
                RollNum = 9,
                City = "Karachi",
                Age = 14
            };
            var std10 = new Student()
            {
                Name = "Asim",
                RollNum = 10,
                City = "Karachi",
                Age = 16
            };
            var std11 = new Student()
            {
                Name = "Haris",
                RollNum = 11,
                City = "Karachi",
                Age = 19
            };
            var std12 = new Student()
            {
                Name = "Akbar",
                RollNum = 12,
                City = "Karachi",
                Age = 13
            };
            var std13 = new Student()
            {
                Name = "Aslam",
                RollNum = 13,
                City = "Karachi",
                Age = 23
            };
            var std14 = new Student()
            {
                Name = "Aswad",
                RollNum = 14,
                City = "Islamabad",
                Age = 15
            };
            var std15 = new Student()
            {
                Name = "Ahsan",
                RollNum = 15,
                City = "Islamabad",
                Age = 24
            };
            var std16 = new Student()
            {
                Name = "Abdullah",
                RollNum = 16,
                City = "Islamabad",
                Age = 17
            };
            var std17 = new Student()
            {
                Name = "Safiullah",
                RollNum = 17,
                City = "Faislabad",
                Age = 15
            };
            var std18 = new Student()
            {
                Name = "Saadullah",
                RollNum = 18,
                City = "Karachi",
                Age = 27
            };
            var std19 = new Student()
            {
                Name = "Faizan",
                RollNum = 19,
                City = "Quetta",
                Age = 17
            };
            var std20 = new Student()
            {
                Name = "Usama",
                RollNum = 20,
                City = "Karachi",
                Age = 22
            };

            var dat = new List<Student>();
            dat.Add(std1);
            dat.Add(std2);
            dat.Add(std3);
            dat.Add(std4);
            dat.Add(std5);
            dat.Add(std6);
            dat.Add(std7);
            dat.Add(std8);
            dat.Add(std9);
            dat.Add(std10);
            dat.Add(std11);
            dat.Add(std12);
            dat.Add(std13);
            dat.Add(std14);
            dat.Add(std15);
            dat.Add(std16);
            dat.Add(std17);
            dat.Add(std18);
            dat.Add(std19);
            dat.Add(std20);

            var std = dat.Where(x => x.RollNum == _rollNum).FirstOrDefault();

            return std;
        }
    }
    
}