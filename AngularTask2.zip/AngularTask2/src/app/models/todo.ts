export interface Todo {
    title: string;
    description: string;
  }