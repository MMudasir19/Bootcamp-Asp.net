﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace aspnet
{
    public partial class calculator : System.Web.UI.Page
    {


        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            double num1 = Convert.ToInt32(this.TextBox1.Text);
            double num2 = Convert.ToInt32(this.TextBox2.Text);
            var optr = this.DropDownList1.SelectedValue.ToString();

            double answer = 0;

            if (optr == "%2B")
            {
                answer = num1 + num2;
            }
            else if (optr == "-")
            {
                answer = num1 - num2;
            }
            else if (optr == "*")
            {
                answer = num1 * num2;
            }
            else
            {
                answer = num1 / num2;
            }
            TextBox3.Text = answer.ToString();
            TextBox3.ForeColor = System.Drawing.Color.Green;
            {
                string value1 = TextBox1.Text.ToString();
                string value2 = TextBox2.Text.ToString();
                string result = TextBox3.Text.ToString();
                
                Response.Redirect("AnswerPage.aspx?" + "&" + "value1=" + value1 + "&" + "value2=" + value2 + "&" + "SelectedOperator=" + optr + "&" + "Result=" + result);
            }
        }
        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {
        }
        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {
        }

        protected void TextBox3_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}