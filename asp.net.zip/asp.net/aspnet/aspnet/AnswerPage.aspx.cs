﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace aspnet
{
    public partial class AnswerPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string value1 = Request.QueryString["value1"].ToString();
            this.Label1.Text = "First value =" + value1.ToString();
            string value2 = Request.QueryString["value2"].ToString();
            this.Label2.Text = "Second value =" + value2.ToString();
            string optr = Request.QueryString["SelectedOperator"].ToString();
            this.Label4.Text = "Operator =" + optr.ToString();
            string result = Request.QueryString["result"].ToString();
            this.Label3.Text = "answer =" + result.ToString();
        }
    }
}