﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace stateManagementTask2
{
    public partial class stateManagementTask2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void btnSubmit(object sender, EventArgs e)
        {
            ViewState["fnameV"] = fname.Text;
            ViewState["passwordV"] = password.Text;
            fnameH.Value = Convert.ToString(fname.Text);
            passwordH.Value = Convert.ToString(password.Text);
            fname.Text = password.Text = string.Empty;
        }
        
        protected void btnViewSubmit(object sender, EventArgs e)
        {
            if (ViewState["fnameV"] != null)
            {
                fname.Text = ViewState["fnameV"].ToString();
            }
            if (ViewState["fnameV"] != null)
            {
                password.Text = ViewState["passwordV"].ToString();
            }
        }
        protected void btnHiddenSubmit(object sender, EventArgs e)
        {
            fname.Text = Convert.ToString(fnameH.Value);
            password.Text = Convert.ToString(passwordH.Value);
        }
    }
}