﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace gridViewTask2
{
    public partial class gridviewTask2 : System.Web.UI.Page
    {
        public class Employee
        {
            //Attributes of Class
            public string employeeName { get; set; }
            public string employeeRole { get; set; }
            public int employeeID { get; set; }
            public string employeeSalary { get; set; }
            public string employeeAddress { get; set; }

            //Construtor
            public Employee(string name, string role, int id, string salary, string Address)
            {
                employeeName = name;
                employeeRole = role;
                employeeID = id;
                employeeSalary = salary;
                employeeAddress = Address;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            // List of Employees for making a database
            List<Employee> dataBaseOfEmployees = new List<Employee>();
            // dummy Employee for populating Database
            Employee dummyEmployee = new Employee("name", "role", 0, "$2000", "address");

            // Random Number Generator
            Random random = new Random();

            // Loop for populating list
            for (int i = 0; i < 1000; i++)
            {
                int num = random.Next(10, 99);
                string temp = i.ToString() + num.ToString();
                dummyEmployee = new Employee("name: " + i, "role: " + i, Convert.ToInt32(temp), "$200" + i, ("street No " + i + ", House No " + i + ", Area No " + i));
                dataBaseOfEmployees.Add(dummyEmployee);
            }
            //Mainataining data in session
            if (Session["tempTable"] is null)
            {
                Session["tempTable"] = dataBaseOfEmployees;
            }

            // binding of list
            if (!IsPostBack)
            {
                myGrid.DataSource = dataBaseOfEmployees;
                myGrid.DataBind();
            }

        }
        // Page Indexing Functionality
        protected void myGrid_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            myGrid.PageIndex = e.NewPageIndex;
            BindData();
        }

        // Selecting Index Functionality
        protected void myGrid_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
        {
            myGrid.SelectedIndex = e.NewSelectedIndex;
            List<Employee> sourceData = (List<Employee>)Session["tempTable"];
            Employee rowUpdate = sourceData[Convert.ToInt32(Session["pageSize"]) * Convert.ToInt32(Session["newPage"]) + e.NewSelectedIndex];
            
            Session["employee"] = rowUpdate;
            Response.Redirect("Details.aspx");
            BindData();
        }

        // Row Editing Functionality
        protected void myGrid_RowEditing(object sender, GridViewEditEventArgs e)
        {
            myGrid.EditIndex = e.NewEditIndex;
            BindData();
        }
        // Row Editing Functionality
        protected void MyGrid_RowEditing(object sender, GridViewEditEventArgs e)
        {
            myGrid.EditIndex = e.NewEditIndex;
            BindData();
        }

        // Bind Data Functionality
        private void BindData()
        {
            myGrid.DataSource = Session["tempTable"];
            myGrid.DataBind();
        }
        // Row update Functionality
        protected void myGrid_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            // Temporary list of Employess
            List<Employee> sourceData = (List<Employee>)Session["tempTable"];

            //Editing Temporary List
            Employee rowUpdate = sourceData[Convert.ToInt32(Session["pageSize"]) * Convert.ToInt32(Session["newPage"]) + e.RowIndex];
            rowUpdate.employeeName = Convert.ToString(e.NewValues["employeeName"]);
            rowUpdate.employeeRole = Convert.ToString(e.NewValues["employeeRole"]);

            // OverRiding the session Values
            Session["tempTable"] = sourceData;
            myGrid.EditIndex = -1;
            BindData();

        }
        //Row Delete Functionality
        protected void myGrid_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            List<Employee> sourceData = (List<Employee>)Session["tempTable"];
            sourceData.RemoveAt(e.RowIndex);
            myGrid.DataSource = sourceData;
            BindData();
        }

        // Cancel button Functionality
        protected void myGrid_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            myGrid.EditIndex = -1;
            BindData();
        }
        // Search Button Functionality
        protected void searchBtn_Click(object sender, EventArgs e)
        {
            /* GridViewRow row = myGrid.Rows[e.NewEditIndex];
            if (!string.IsNullOrEmpty(textSearch.Text))
             {
                 textSearch.Text = "Found " + GridView.Rows.Count(
                     " rows matching keyword '" + textSearch.Text + "'.");
            }
             BindData();*/
        }

        protected void myGrid_SelectedIndexChanged(object sender, EventArgs e)
        {
            Session["tempValue"] = myGrid.SelectedRow;
        }
    }

}